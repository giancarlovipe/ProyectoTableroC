/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Tablero.h
 * Author: jeanc
 *
 * Created on May 25, 2021, 4:14 PM
 */

#ifndef TABLERO_H
#define TABLERO_H
#include "Pieza.h"

#ifdef __cplusplus
extern "C" {
#endif

void newTablero();


#ifdef __cplusplus
}
#endif

#endif /* TABLERO_H */

